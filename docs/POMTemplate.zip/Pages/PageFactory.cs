﻿using System;
using WebAndWebApiAutomation;

namespace $projectname$.$safeprojectname$
{
    public static class PageFactory
    {
        private static WebAutomation _webAutomationInstance;

        public static T GetPage<T>(TestRunConfiguration testConfiguration)
        {
            //Example implementation
            //if (typeof(T) == typeof(IAgentPortalDashboardPage))
            //{
            //    return (T)(IAgentPortalDashboardPage)new AgentPortalDashboardPage(webAutomation, testConfiguration);
            //}

            //Leave this to handle improperly or incomplete implementations
            throw new NotImplementedException($"Creation of {typeof(T)} interface is not supported yet.");
        }
        
        private static void SetInstances(TestRunConfiguration testConfiguration)
        {
            if(_webAutomationInstance == null)
                _webAutomationInstance = new WebAutomation(testConfiguration.DriverPath, testConfiguration.WaitOverride);
        }
    }
}
