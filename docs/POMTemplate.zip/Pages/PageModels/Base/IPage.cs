﻿using System;

namespace $safeprojectname$.PageModels.Base
{
    public interface IPage
    {
        /// <summary>
        /// Navigates to the Page
        /// </summary>
        void Goto();
        /// <summary>
        /// Evaluates the page is at the expected URL
        /// </summary>
        bool IsAt();
        /// <summary>
        /// Returns the current URL
        /// </summary>
        string GetCurrentUrl();
        /// <summary>
        /// Closes the page instance and releases all resources associated with it
        /// </summary>
        void Close();
        /// <summary>
        /// Validates all the elements expected on the page can be found
        /// </summary>
        bool ExpectedElementsArePresent();
        /// <summary>
        /// Takes a screenshot of the current pages
        /// </summary>
        /// <param name="screenshotName"></param>
        void TakeScreenShot(string screenshotName);
        void CloseLastTab(string mainWindow);
        void CloseTab(string windowToClose, string windowToBack);
        void SwitchToLastTab();
        void CloseAllTabsExceptCurrent();
        void GetExecuteTest(Action testMethod);
    }
}
