﻿using System;
using System.Collections.Generic;
using WebAndWebApiAutomation;
using static WebAndWebApiAutomation.WebAutomationEnums;

namespace $safeprojectname$.PageModels.Base
{
    public class PageModelBase
    {
        internal DriverType _driverType;
        internal static List<DriverType> _driverTypes;
        internal WebAutomation _webAutomation;
        internal IWebDriverManager _webDriverManager;
        internal ILogger _logger;
        internal ITestExecutor _testExecutor;
        internal TestRunConfiguration _testConfiguration;

        internal PageModelBase(WebAutomation webAutomation, TestRunConfiguration testConfiguration)
        {
            _webAutomation = webAutomation;
            _testConfiguration = testConfiguration;
            _webDriverManager = _webAutomation.GetIWebDriverManager();

            //Build up the driver type collection
            _driverTypes = BuildBrowserList(testConfiguration.BrowsersToTest);

            //Build the logger settings from the configuration object
            var loggerSettings = new LoggerSettings()
            {
                LogFileName = testConfiguration.LogFileName,
                LogFilePath = testConfiguration.LogPath,
                AppendDateToLogFile = testConfiguration.AppendDateToLogFile,
                DateFormat = testConfiguration.DateFormat,
                GenerateFailureLog = testConfiguration.GenerateFailureLog,
                NumberOfLogFilesToPreserve = testConfiguration.NumberOfLogFilesToPreserve
            };
            //Get the unified logger
            _logger = _webAutomation.GetLogger(loggerSettings);
            //Get the unified test executor
            _testExecutor = _webAutomation.GetTestExecutor(false, testConfiguration.LogPath);
        }

        #region IPage Inteface Methods
        public void CloseLastTab(string mainWindow)
        {
            _webDriverManager.CloseLastTabWithActiveDriver(mainWindow);
        }

        public void CloseTab(string tabToClose, string targetTab)
        {
            _webDriverManager.CloseTabWithActiveDriver(tabToClose, targetTab);
        }

        public void SwitchToLastTab()
        {
            _webDriverManager.SwitchToLastTabWithActiveDriver();
        }

        public void CloseAllTabsExceptCurrent()
        {
            _webDriverManager.CloseAllTabsExceptCurrentWithActiveDriver();
        }

        public string GetCurrentUrl()
        {
            return _webDriverManager.GetActiveDriverUrl();
        }

        public void TakeScreenShot(string screenshotName)
        {
            _webAutomation.TakeScreenShot(_webDriverManager, _testConfiguration.ScreenShotPath, screenshotName);
        }

        public void Close()
        {
            _webDriverManager.QuitDriverInstance(_driverType);
        }

        public void ExecuteTest(Action testMethod)
        {
            _testExecutor.Execute(() =>
            {
                foreach (var driver in _driverTypes)
                {
                    _webDriverManager.SetActiveDriver(driver);
                    testMethod();
                }

            }, _webDriverManager);
        }

        #endregion

        private List<DriverType> BuildBrowserList(string browsersFromConfig)
        {
            var browsers = browsersFromConfig.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            List<DriverType> drivers = new List<DriverType>();
            foreach (var browserName in browsers)
            {
                if (browserName.ToLower().Equals(DriverType.Chrome.ToString().ToLower()))
                    drivers.Add(DriverType.Chrome);

                if (browserName.ToLower().Equals(DriverType.Firefox.ToString().ToLower()))
                    drivers.Add(DriverType.Firefox);

                if (browserName.ToLower().Equals(DriverType.Edge.ToString().ToLower()))
                    drivers.Add(DriverType.Edge);

                if (browserName.ToLower().Equals(DriverType.InternetExplorer.ToString().ToLower()))
                    drivers.Add(DriverType.InternetExplorer);
            }

            return drivers;
        }

        internal void Navigate(string url)
        {
            string newUrl = url;
            string baseUrl = _testConfiguration.BaseUrl;

            var x = url.IndexOf(baseUrl);
            if (x >= 0)
            {
                newUrl = $"{baseUrl}.{url.Substring(x)}";
            }

            if (url.IndexOf("/") == 0)
            {
                newUrl = $"{baseUrl}{url}";
            }

            _webDriverManager.NavigateWithActiveDriver(newUrl);
        }
    }
}
