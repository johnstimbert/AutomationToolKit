﻿using System.IO;

namespace $safeprojectname$
{
    public sealed class TestRunConfiguration
    {
        public TestRunConfiguration()
        {
            DriverPath = Directory.GetCurrentDirectory();
        }

        public string BaseUrl { get; set; }
        public string BrowsersToTest { get; set; }
        public string ScreenShotPath { get; set; }
        public string DriverPath { get; private set; }
        public int WaitOverride { get; set; }

        //Logger Settings
        public int NumberOfLogFilesToPreserve { get; set; }
        public bool AppendDateToLogFile { get; set; }
        public bool GenerateFailureLog { get; set; }
        public string LogFileName { get; set; }
        public string LogPath { get; set; }
        public string DateFormat { get; set; }
    }
}
