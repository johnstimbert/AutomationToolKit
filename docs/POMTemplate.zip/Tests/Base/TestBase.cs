﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using $safeprojectname$.Pages;
using $safeprojectname$.Pages.PageModels.Base;
using System.Configuration;

namespace $safeprojectname$.Base
{
    [TestClass]
    public class TestBase
    {
        private static TestContext _testContext;
        private static TestRunConfiguration _testRunConfiguration;
        internal static IPage _page;

        internal const string _smokeTestCategory = "SmokeTest";

        [AssemblyInitialize()]
        public static void TestRunSetup(TestContext testContex)
        {
            _testContext = testContex;

            _testRunConfiguration = new TestRunConfiguration()
            {
                BaseUrl = ConfigurationManager.AppSettings["BaseUrl"],
                BrowsersToTest = ConfigurationManager.AppSettings["BrowsersToTest"],
                ScreenShotPath = ConfigurationManager.AppSettings["ScreenShotPath"],
                WaitOverride = int.Parse(ConfigurationManager.AppSettings["WaitOverride"]),
                NumberOfLogFilesToPreserve = int.Parse(ConfigurationManager.AppSettings["NumberOfLogFilesToPreserve"]),
                AppendDateToLogFile = bool.Parse(ConfigurationManager.AppSettings["AppendDateToLogFile"]),
                GenerateFailureLog = bool.Parse(ConfigurationManager.AppSettings["GenerateFailureLog"]),
                LogFileName = ConfigurationManager.AppSettings["LogFileName"],
                LogPath = ConfigurationManager.AppSettings["LogPath"],
                DateFormat = ConfigurationManager.AppSettings["DateFormat"],
            };
        }

        [AssemblyCleanup]
        public static void TestRunTeardown()
        {
            _page.Close();
        }

        public TestContext TestContext { get { return _testContext; } set { _testContext = value; } }
    }
}
